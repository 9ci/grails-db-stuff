class TestTable {
	 String name
	 Integer age

    static constraints = {
    }
}
