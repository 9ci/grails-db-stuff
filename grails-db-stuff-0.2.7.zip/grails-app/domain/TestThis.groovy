class TestThis {
	 String prop
	 Integer num
	 TestTable testTable
    static constraints = {
    }
}
